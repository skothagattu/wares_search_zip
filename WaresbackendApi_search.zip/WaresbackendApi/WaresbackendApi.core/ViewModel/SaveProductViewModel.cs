﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaresBackendApi.core.ViewModel
{
    public class SaveProductViewModel
    {
        public string PRODUCTNO { get; set; }
        public string REV { get; set; }
        // ... Add other properties from the PRODUCTS table that you want to allow for creation or update
    }
}
