﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaresBackendApi.core.ViewModel
{
    public class ProductViewModel
    {
        public decimal ID { get; set; }
        public string PRODUCTNO { get; set; }
        public string? REV { get; set; }
        public string? ALPHA { get; set; }
        public string? DESCRIPTION { get; set; }
        public string? CONFIGURATION { get; set; }
        public decimal? LLC { get; set; }
        public string? LEVEL1 { get; set; }
        public string? TYPE { get; set; }
        public string? ECR { get; set; }
        public decimal? LISTPRICE { get; set; }
        public string? ACTIVE { get; set; }
        public string? LABEL_DESC { get; set; }
        public string? PRODUCT_SPEC { get; set; }
        public string? LABEL_CONFIG { get; set; }
        public DateTime? DATE_REQ { get; set; }
        public DateTime? DATE_DUE { get; set; }
        public string? LEVEL2 { get; set; }
        public string? LEVEL3 { get; set; }
        public string? LEVEL4 { get; set; }
        public string? LEVEL5 { get; set; }
        public int? SEQUENCE_NUM { get; set; }
        public string? LOCATION_WARES { get; set; }
        public string? LOCATION_ACCPAC { get; set; }
        public string? LOCATION_MISYS { get; set; }
        public string? LEVEL6 { get; set; }
        public string? LEVEL7 { get; set; }
        public string? INST_GUIDE { get; set; }

        // You can add any additional properties or methods needed for the UI here
    }

}
