﻿namespace WaresbackendApi.core
{
    public class Class1
    {

    }
}