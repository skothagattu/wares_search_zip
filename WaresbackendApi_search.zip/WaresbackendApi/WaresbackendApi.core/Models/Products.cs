﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

[Table("PRODUCTS")]
/*public class Products
{
    
    public decimal ID { get; set; }
    [Key]
    [Required, StringLength(24)]
    public string PRODUCTNO { get; set; }

    [StringLength(2)]
    public string? REV { get; set; }

    [StringLength(24)]
    public string? ALPHA { get; set; }

    [StringLength(31)]
    public string? DESCRIPTION { get; set; }

    [StringLength(34)]
    public string? CONFIGURATION { get; set; }

    public decimal? LLC { get; set; }

    [StringLength(24)]
    public string? LEVEL1 { get; set; }

    [StringLength(24)]
    public string? TYPE { get; set; }

    [StringLength(50)]
    public string? ECR { get; set; }

    [Column(TypeName = "money")]
    public decimal? LISTPRICE { get; set; }

    public byte[] COMMENTS { get; set; }

    [StringLength(24)]
    public string? ACTIVE { get; set; }

    [StringLength(45)]
    public string? LABEL_DESC { get; set; }

    [StringLength(50)]
    public string? PRODUCT_SPEC { get; set; }

    [StringLength(45)]
    public string? LABEL_CONFIG { get; set; }

    public DateTime? DATE_REQ { get; set; }

    public DateTime? DATE_DUE { get; set; }

    [StringLength(24)]
    public string? LEVEL2 { get; set; }

    [StringLength(24)]
    public string? LEVEL3 { get; set; }

    [StringLength(24)]
    public string? LEVEL4 { get; set; }

    [StringLength(24)]
    public string? LEVEL5 { get; set; }

    public int? SEQUENCE_NUM { get; set; }

    [StringLength(1)]
    public string? LOCATION_WARES { get; set; }

    [StringLength(1)]
    public string? LOCATION_ACCPAC { get; set; }

    [StringLength(1)]
    public string? LOCATION_MISYS { get; set; }

    [StringLength(24)]
    public string? LEVEL6 { get; set; }

    [StringLength(24)]
    public string? LEVEL7 { get; set; }

    [StringLength(50)]
    public string? INST_GUIDE { get; set; }
}*/
public class Products
{
    public decimal ID { get; set; }
    [Required, StringLength(24)]
    public string PRODUCTNO { get; set; }
    [StringLength(2)]
    public string? REV { get; set; }
    [StringLength(24)]
    public string? ALPHA { get; set; }
    [StringLength(31)]
    public string? DESCRIPTION { get; set; }
    [StringLength(34)]
    public string? CONFIGURATION { get; set; }
    public decimal? LLC { get; set; }
    [StringLength(24)]
    public string? LEVEL1 { get; set; }
    [StringLength(24)]
    public string? TYPE { get; set; }
    [StringLength(50)]
    public string? ECR { get; set; }
    public decimal? LISTPRICE { get; set; }
    public byte[]? COMMENTS { get; set; }
    [StringLength(24)]
    public string? ACTIVE { get; set; }
    [StringLength(45)]
    public string? LABEL_DESC { get; set; }
    [StringLength(50)]
    public string? PRODUCT_SPEC { get; set; }
    [StringLength(45)]
    public string? LABEL_CONFIG { get; set; }
    public DateTime? DATE_REQ { get; set; }
    public DateTime? DATE_DUE { get; set; }
    [StringLength(24)]
    public string? LEVEL2 { get; set; }
    [StringLength(24)]
    public string? LEVEL3 { get; set; }
    [StringLength(24)]
    public string? LEVEL4 { get; set; }
    [StringLength(24)]
    public string? LEVEL5 { get; set; }
    public int? SEQUENCE_NUM { get; set; }
    [StringLength(1)]
    public char? LOCATION_WARES { get; set; }
    [StringLength(1)]
    public char? LOCATION_ACCPAC { get; set; }
    [StringLength(1)]
    public char? LOCATION_MISYS { get; set; }
    [StringLength(24)]
    public string? LEVEL6 { get; set; }
    [StringLength(24)]
    public string? LEVEL7 { get; set; }
    [StringLength(50)]
    public string? INST_GUIDE { get; set; }
}

