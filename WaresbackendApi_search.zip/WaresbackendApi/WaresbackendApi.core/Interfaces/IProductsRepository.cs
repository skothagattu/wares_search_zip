﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaresBackendApi.core.Interfaces
{
    public interface IProductsRepository : IGenericRepository<Products>
    {
        // Add the GetByProductNo method definition
    }
}
