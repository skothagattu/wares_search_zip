﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using WaresBackendApi.core.Interfaces;
using WaresBackendApi.core.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WaresBackendApi.Helpers;
using WaresbackendApi.Helpers;

namespace WaresBackendApi.Services
{
    public class ProductService : IProductService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IUnitOfWork unitOfWork, IMapper mapper, ILogger<ProductService> logger)
        {
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<PaginatedResult<ProductViewModel>> GetAllProducts(int pageNumber = 1, int pageSize = 50, string searchQuery = null)
        {
            IQueryable<Products> query = (IQueryable<Products>)_unitOfWork.Products.GetAll();

            // If a search query is provided, filter the products based on it
            if (!string.IsNullOrEmpty(searchQuery))
            {
                query = query.Where(p => EF.Functions.Like(p.PRODUCTNO, $"%{searchQuery}%"));
            }

            var products = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var totalItems = await query.CountAsync();

            var result = new PaginatedResult<ProductViewModel>
            {
                TotalItems = totalItems,
                CurrentPage = pageNumber,
                PageSize = pageSize,
                Items = _mapper.Map<IEnumerable<ProductViewModel>>(products).ToList()
            };

            return result;
        }


        public async Task<ProductViewModel> GetProductByProductNo(string productNo)
        {
            var product = await _unitOfWork.Products.Get(productNo);
            return product != null ? _mapper.Map<ProductViewModel>(product) : null;
        }
    }
}
