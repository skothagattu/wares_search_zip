﻿using WaresbackendApi.Helpers;
using WaresBackendApi.core.ViewModel;
using WaresBackendApi.Helpers;

namespace WaresBackendApi.Services
{
    public interface IProductService
    {
        Task<PaginatedResult<ProductViewModel>> GetAllProducts(int pageNumber = 1, int pageSize = 50, string? searchQuery = null);
        Task<ProductViewModel> GetProductByProductNo(string id);
    }
}
