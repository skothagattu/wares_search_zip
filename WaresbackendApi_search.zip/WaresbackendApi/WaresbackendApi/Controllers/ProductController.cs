﻿using Microsoft.AspNetCore.Mvc;
using WaresBackendApi.core.ViewModel;
using WaresBackendApi.Services;
using WaresBackendApi.Helpers;
using FlutterBackendApi;

namespace WaresBackendApi.Controllers
{
    
        [ApiController]
        [Route("api/[controller]")]
        public class ProductsController : ControllerBase
        {
            private readonly IProductService _productService;  // Use the service instead of the repository

            public ProductsController(IProductService productService)  // Inject the service in the constructor
            {
                _productService = productService;
            }

            [HttpGet("GetAll")]
            [ProducesResponseType(200)]
            [ProducesResponseType(400)]
        public async Task<IActionResult> GetAll(int pageNumber = 1, int pageSize = 50, string? searchQuery = null)
        {
            try
            {
                var products = await _productService.GetAllProducts(pageNumber, pageSize, searchQuery);
                var resp = new ApiResponse { Status = true, Message = "Products fetched successfully", Data = products };
                return Ok(resp);
            }
            catch (Exception ex)
            {
                var resp = new ApiResponse { Status = false, Message = $"An error occurred: {ex.Message}", Data = null };
                return BadRequest(resp);
            }
        }
        [HttpGet("{productNo}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> GetById(string productNo)
        {
            var product = await _productService.GetProductByProductNo(productNo);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }
    }
    
}
