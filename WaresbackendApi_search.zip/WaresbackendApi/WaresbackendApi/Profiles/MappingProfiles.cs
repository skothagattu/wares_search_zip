﻿using AutoMapper;
using WaresBackendApi.core.ViewModel;

namespace WaresBackendApi.Profiles
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<Products, SaveProductViewModel>().ReverseMap();
            CreateMap<Products, ProductViewModel>().ReverseMap();
        }
    }
}
