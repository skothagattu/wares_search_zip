﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaresBackendApi.infrastructure
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> dbContextOptions) : base(dbContextOptions)
        {
        }
        public DbSet<Products> Products { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Products>(entity =>
            {
                entity.Property(e => e.ID).HasPrecision(18, 0);
                entity.Property(e => e.LLC).HasPrecision(18, 0);
                entity.Property(e => e.LISTPRICE).HasColumnType("money");
                entity.Property(e => e.COMMENTS).HasColumnType("image");
                entity.Property(e => e.DATE_REQ).HasColumnType("datetime");
                entity.Property(e => e.DATE_DUE).HasColumnType("datetime");
                // Add configurations for other properties as needed
            });
        }

    }
}
