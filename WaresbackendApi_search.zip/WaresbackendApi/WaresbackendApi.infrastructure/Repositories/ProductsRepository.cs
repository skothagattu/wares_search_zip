﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WaresBackendApi.core.Interfaces;

namespace WaresBackendApi.infrastructure.Repositories
{
    internal class ProductsRepository : GenericRepository<Products>, IProductsRepository
    {
        private readonly ApplicationDbContext _context;
        public ProductsRepository(ApplicationDbContext dbContext): base(dbContext) 
        {
        _context = dbContext;
        }
        public IQueryable<Products> GetAll()
        {
            return _context.Products;
        }
    }
}
