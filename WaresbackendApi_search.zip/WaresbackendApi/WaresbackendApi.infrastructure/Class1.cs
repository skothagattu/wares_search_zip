﻿namespace WaresbackendApi.infrastructure
{
    public class Class1
    {

    }
}